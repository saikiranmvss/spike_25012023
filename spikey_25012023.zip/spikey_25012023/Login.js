import 'bootstrap/dist/css/bootstrap.css';
import $ from 'jquery';
import { useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import './Login.css';
import { Link } from "react-router-dom";
import React , { useContext } from 'react';
import {SocketContext} from './App';
// import Cookies from 'universal-cookie';

// var cookies = new Cookies();


var navigate = '';
var details='';
function testing(){    
  
var email=$('#email').val();
var password=$('#password').val()
    details={email,password};

$.ajax({
  url:'http://192.168.0.144:9999/validate',
  data:details,
  type:"post",
  success:function(data){        
    
    if(data.msgs==='email_err'){
      console.log('Entered email is not valid');
    }else if(data.msgs==='pass_err'){
      console.log('Incorrect password');
    }else{      
      // sessionStorage.setItem('userId',data.msgs);
      socket.emit('loggedin',data.msgs);
      // cookies.set('userId', data.msgs, { path: '/' });      
      navigate("/Allusers");
    }
  }
})
}
var socket='';

function Login() {  

  useEffect(()=>{
    $('.mobile-bottom-nav').hide();
  },[])
  
  socket = useContext(SocketContext);
  navigate = useNavigate();
    return (
      <div className="d-flex align-items-center wh-logs">
      <div className="form-box">
      <div className="container login-form">
          <div className="row">
              <div className="col-12 form-fields title-text" ><span>LOGIN FORM</span></div>
              <div className="col-12 form-fields"><input className="form-control" placeholder="Email address" type="text" name="email" id="email" /></div>
              <div className="col-12 form-fields"><input className="form-control" type="password" placeholder="Password" name="password" id="password" /></div>
              <div className="col-12 form-fields"><input style={{background:"#1b2d41"}} type="button" className="btn btn-primary" value="Login" id="login" name="login" onClick={testing} /></div>
              <span style={{cursor:'pointer',textAlign:'center',fontSize:'17px',marginBottom:'1rem',marginTop:'0rem'}}>Need an account ? <strong><Link to="/Signup" style={{color:'rgb(27, 45, 65)',textDecoration:'none'}}>Signup</Link></strong></span>
          </div>
      </div>
  </div>
  </div>    
    );
  }

  export default Login;